
module top (
    input logic i_clk,
    input logic i_rstn
);
    reg w_rstn;
    reg [31:0] count_cyc = 0;
    always @(posedge i_clk ) begin
        w_rstn <= i_rstn;
    end
    RISCV  dut(
        .i_clk  (i_clk),
        .i_rstn (w_rstn)
    );
    initial begin
        //$display("address \t bank3 \t bank2 \t bank1 \t bank0 \n ");
    end
    always @(posedge i_clk) begin
        count_cyc <= count_cyc + 1;
        // if (count_cyc >= 2) begin
        //     $display( "t0: %h", dut.datapath_inst0.RF_inst0.register[5]);
        //     $display( "t1: %h", dut.datapath_inst0.RF_inst0.register[6]);
        //     $display( "t2: %h", dut.datapath_inst0.RF_inst0.register[7]);
        //     $display( "t3: %h", dut.datapath_inst0.RF_inst0.register[28]);
        //     $display( "t4: %h", dut.datapath_inst0.RF_inst0.register[29]);
        //     $fflush();
        // end
        // $display("%d \t   %h  \t  %h   \t   %h  \t   %h  \n ",  dut.datapath_inst0.IMEM_inst0.i_address,
        //                                                         dut.datapath_inst0.DMEM_inst0.w_bank3, 
        //                                                         dut.datapath_inst0.DMEM_inst0.w_bank2, 
        //                                                         dut.datapath_inst0.DMEM_inst0.w_bank1, 
        //                                                         dut.datapath_inst0.DMEM_inst0.w_bank0);
        // $fflush();
    end


endmodule
