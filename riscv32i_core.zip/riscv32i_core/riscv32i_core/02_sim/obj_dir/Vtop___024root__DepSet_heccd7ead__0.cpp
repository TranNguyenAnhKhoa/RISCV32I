// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop__pch.h"
#include "Vtop___024root.h"

VL_INLINE_OPT void Vtop___024root___act_sequent__TOP__0(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___act_sequent__TOP__0\n"); );
    // Body
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next 
        = ((1U & ((0x4000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                   ? ((0x2000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                       ? ((0x1000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                           ? (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))
                           : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))
                       : ((0x1000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                           ? (((vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                >> 0x1fU) != (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                              >> 0x1fU))
                               ? (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                  >> 0x1fU) : (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult)))
                           : (((vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                >> 0x1fU) != (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                              >> 0x1fU))
                               ? (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                  >> 0x1fU) : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))))
                   : ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                >> 0xdU))) && (1U & 
                                               ((0x1000U 
                                                 & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                                 ? 
                                                (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal))
                                                 : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal))))))
            ? vlSelf->top__DOT__dut__DOT__w_addr_branch_mem
            : ((IData)(4U) + vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current));
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current 
        = (((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
              & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                  == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                               >> 0xfU))) | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                             == (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U))))) 
             | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                    & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                        == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     >> 0xfU))) | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                   == 
                                                   (0x1fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 0x14U))))) 
                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                      & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                          == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0xfU))) | 
                         ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                          == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0x14U)))))))) 
            | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                >> 5U) & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                           == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                        >> 0xfU))) 
                          | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                             & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 0xfU)))))))
            ? vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current
            : vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next);
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction 
        = ((vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem
            [(0x3ffU & vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current)] 
            << 0x18U) | ((vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem
                          [(0x3ffU & ((IData)(1U) + vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current))] 
                          << 0x10U) | ((vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem
                                        [(0x3ffU & 
                                          ((IData)(2U) 
                                           + vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current))] 
                                        << 8U) | vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem
                                       [(0x3ffU & ((IData)(3U) 
                                                   + vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current))])));
}

void Vtop___024root___eval_act(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_act\n"); );
    // Body
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        Vtop___024root___act_sequent__TOP__0(vlSelf);
    }
}

extern const VlUnpacked<CData/*3:0*/, 64> Vtop__ConstPool__TABLE_hf09f0c7c_0;

VL_INLINE_OPT void Vtop___024root___nba_sequent__TOP__0(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___nba_sequent__TOP__0\n"); );
    // Init
    CData/*5:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v0;
    __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v0 = 0;
    CData/*4:0*/ __Vdlyvdim0__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32;
    __Vdlyvdim0__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 = 0;
    IData/*31:0*/ __Vdlyvval__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32;
    __Vdlyvval__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32;
    __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 = 0;
    CData/*7:0*/ __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2;
    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 = 0;
    CData/*5:0*/ __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3;
    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3 = 0;
    CData/*0:0*/ __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3 = 0;
    // Body
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v0 = 0U;
    __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 = 0U;
    vlSelf->top__DOT__count_cyc = ((IData)(1U) + vlSelf->top__DOT__count_cyc);
    if (vlSelf->top__DOT__dut__DOT__w_mem_write_exe) {
        if ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
            __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 
                = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
            __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 
                = (vlSelf->top__DOT__dut__DOT__w_read_data2_exe 
                   >> 0x18U);
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
            __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 
                = (0xffU & (vlSelf->top__DOT__dut__DOT__w_read_data2_exe 
                            >> 8U));
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
            __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 
                = (0xffU & (vlSelf->top__DOT__dut__DOT__w_read_data2_exe 
                            >> 0x10U));
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
        } else if ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
            if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                          >> 1U)))) {
                __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 
                    = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
                __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 = 1U;
                __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1 
                    = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                >> 2U));
                __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 
                    = (0xffU & (vlSelf->top__DOT__dut__DOT__w_read_data2_exe 
                                >> 8U));
                __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 = 1U;
                __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1 
                    = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                >> 2U));
            }
            if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 
                    = (0xffU & (vlSelf->top__DOT__dut__DOT__w_read_data2_exe 
                                >> 8U));
                __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 = 1U;
                __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1 
                    = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                >> 2U));
                __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 
                    = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
                __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 = 1U;
                __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1 
                    = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                >> 2U));
            }
        } else if ((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
            if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                          >> 1U)))) {
                if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 
                        = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
                    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 = 1U;
                    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2 
                        = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                    >> 2U));
                }
                if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 
                        = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
                    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 = 1U;
                    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2 
                        = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                    >> 2U));
                }
            }
            if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 
                        = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
                    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 = 1U;
                    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2 
                        = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                    >> 2U));
                }
                if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                    __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 
                        = (0xffU & vlSelf->top__DOT__dut__DOT__w_read_data2_exe);
                    __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 = 1U;
                    __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2 
                        = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                    >> 2U));
                }
            }
        } else {
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
            __Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3 
                = (0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                            >> 2U));
        }
    }
    vlSelf->top__DOT__dut__DOT__w_ALU_src_d = ((1U 
                                                & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                               && (1U 
                                                   & ((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal) 
                                                      >> 3U)));
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg_mem = 
        ((1U & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
         && (IData)(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_exe));
    vlSelf->top__DOT__dut__DOT__w_branch_exe = ((1U 
                                                 & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                && (IData)(vlSelf->top__DOT__dut__DOT__w_branch_d));
    vlSelf->top__DOT__dut__DOT__w_mem_read_exe = ((1U 
                                                   & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d));
    vlSelf->top__DOT__dut__DOT__w_funct7_30_d = ((1U 
                                                  & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                 && (1U 
                                                     & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 0x1eU)));
    if (vlSelf->top__DOT__w_rstn) {
        __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v0 = 1U;
        vlSelf->top__DOT__dut__DOT__w_ALUOp_d = 0U;
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current = 0U;
        vlSelf->top__DOT__dut__DOT__w_read_data1_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_read_data2_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem = 0U;
        vlSelf->top__DOT__dut__DOT__w_ALU_out_mem = 0U;
        vlSelf->top__DOT__dut__DOT__w_addr_branch_mem = 0U;
        vlSelf->top__DOT__dut__DOT__w_rs2_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_rs1_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_read_data2_exe = 0U;
        vlSelf->top__DOT__dut__DOT__w_funct3_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_rd_mem = 0U;
        vlSelf->top__DOT__dut__DOT__w_ALU_out_exe = 0U;
        vlSelf->top__DOT__dut__DOT__w_addr_branch_exe = 0U;
        vlSelf->top__DOT__dut__DOT__w_rd_exe = 0U;
        vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_addr_current_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_rd_d = 0U;
        vlSelf->top__DOT__dut__DOT__w_addr_current_f = 0U;
        vlSelf->top__DOT__dut__DOT__w_instruction_f = 0U;
    } else {
        if (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_mem) 
             & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem)))) {
            __Vdlyvval__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 
                = vlSelf->top__DOT__dut__DOT__w_write_back_wb;
            __Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 = 1U;
            __Vdlyvdim0__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32 
                = vlSelf->top__DOT__dut__DOT__w_rd_mem;
        }
        vlSelf->top__DOT__dut__DOT__w_ALUOp_d = (3U 
                                                 & (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal));
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current 
            = vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next;
        vlSelf->top__DOT__dut__DOT__w_read_data1_d 
            = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1;
        vlSelf->top__DOT__dut__DOT__w_read_data2_d 
            = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2;
        vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem 
            = (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0 
               | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1 
                  | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2 
                     | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3 
                        | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4 
                           | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5 
                              | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6 
                                 | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7 
                                    | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8 
                                       | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9 
                                          | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10 
                                             | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11 
                                                | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12 
                                                   | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13 
                                                      | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15))))))))))))));
        vlSelf->top__DOT__dut__DOT__w_ALU_out_mem = vlSelf->top__DOT__dut__DOT__w_ALU_out_exe;
        vlSelf->top__DOT__dut__DOT__w_addr_branch_mem 
            = vlSelf->top__DOT__dut__DOT__w_addr_branch_exe;
        vlSelf->top__DOT__dut__DOT__w_rs2_d = (0x1fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 0x14U));
        vlSelf->top__DOT__dut__DOT__w_rs1_d = (0x1fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 0xfU));
        vlSelf->top__DOT__dut__DOT__w_read_data2_exe 
            = vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output;
        vlSelf->top__DOT__dut__DOT__w_funct3_d = (7U 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 0xcU));
        vlSelf->top__DOT__dut__DOT__w_rd_mem = vlSelf->top__DOT__dut__DOT__w_rd_exe;
        vlSelf->top__DOT__dut__DOT__w_ALU_out_exe = vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out;
        vlSelf->top__DOT__dut__DOT__w_addr_branch_exe 
            = (vlSelf->top__DOT__dut__DOT__w_addr_current_d 
               + vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d);
        vlSelf->top__DOT__dut__DOT__w_rd_exe = vlSelf->top__DOT__dut__DOT__w_rd_d;
        vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d 
            = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out;
        vlSelf->top__DOT__dut__DOT__w_addr_current_d 
            = vlSelf->top__DOT__dut__DOT__w_addr_current_f;
        vlSelf->top__DOT__dut__DOT__w_rd_d = (0x1fU 
                                              & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 7U));
        vlSelf->top__DOT__dut__DOT__w_addr_current_f 
            = vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current;
        vlSelf->top__DOT__dut__DOT__w_instruction_f 
            = vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v0;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v1;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v2;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0__v3] = 0U;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v0;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v1;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v2;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3__v3] = 0U;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v0;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v1;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v2;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1__v3] = 0U;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v0;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v1;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2] 
            = __Vdlyvval__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v2;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2[__Vdlyvdim0__top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2__v3] = 0U;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v0) {
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[1U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[2U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[3U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[4U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[5U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[6U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[7U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[8U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[9U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0xaU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0xbU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0xcU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0xdU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0xeU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0xfU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x10U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x11U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x12U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x13U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x14U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x15U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x16U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x17U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x18U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x19U] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x1aU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x1bU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x1cU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x1dU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x1eU] = 0U;
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0x1fU] = 0U;
    }
    if (__Vdlyvset__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32) {
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[__Vdlyvdim0__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32] 
            = __Vdlyvval__top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register__v32;
    }
    vlSelf->top__DOT__dut__DOT__w_mem_write_exe = (
                                                   (1U 
                                                    & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                   && (IData)(vlSelf->top__DOT__dut__DOT__w_mem_write_d));
    vlSelf->top__DOT__dut__DOT__w_reg_write_mem = (
                                                   (1U 
                                                    & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                   && (IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_exe));
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg_exe = 
        ((1U & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
         && (IData)(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_d));
    vlSelf->top__DOT__dut__DOT__w_branch_d = ((1U & 
                                               (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                              && (1U 
                                                  & ((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal) 
                                                     >> 7U)));
    vlSelf->top__DOT__dut__DOT__w_write_back_wb = ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_mem)
                                                    ? vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem
                                                    : vlSelf->top__DOT__dut__DOT__w_ALU_out_mem);
    if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe)))) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15 = 0U;
    }
    vlSelf->top__DOT__dut__DOT__w_mem_read_d = ((1U 
                                                 & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                && (1U 
                                                    & ((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal) 
                                                       >> 6U)));
    vlSelf->top__DOT__dut__DOT__w_mem_write_d = ((1U 
                                                  & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                 && (1U 
                                                     & ((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal) 
                                                        >> 4U)));
    __Vtableidx1 = (((IData)(vlSelf->top__DOT__dut__DOT__w_funct7_30_d) 
                     << 5U) | (((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                                << 2U) | (IData)(vlSelf->top__DOT__dut__DOT__w_ALUOp_d)));
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl 
        = Vtop__ConstPool__TABLE_hf09f0c7c_0[__Vtableidx1];
    vlSelf->top__DOT__dut__DOT__w_reg_write_exe = (
                                                   (1U 
                                                    & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                   && (IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d));
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg_d = ((1U 
                                                   & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                  && (1U 
                                                      & ((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal) 
                                                         >> 5U)));
    if (vlSelf->top__DOT__dut__DOT__w_mem_read_exe) {
        if ((1U & (~ ((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                      >> 2U)))) {
            if ((1U & (~ ((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                          >> 1U)))) {
                if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d)))) {
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                    }
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                    }
                }
                if ((1U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4 
                            = (((- (IData)((1U & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                                  [
                                                  (0x3fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                      >> 2U))] 
                                                  >> 7U)))) 
                                << 0x10U) | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                              [(0x3fU 
                                                & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                   >> 2U))] 
                                              << 8U) 
                                             | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                             [(0x3fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                  >> 2U))]));
                    }
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5 
                            = (((- (IData)((1U & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                                  [
                                                  (0x3fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                      >> 2U))] 
                                                  >> 7U)))) 
                                << 0x10U) | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                              [(0x3fU 
                                                & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                   >> 2U))] 
                                              << 8U) 
                                             | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                             [(0x3fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                  >> 2U))]));
                    }
                }
            }
            if ((2U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
                if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d)))) {
                    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7 
                        = ((0xffffU & vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7) 
                           | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))] 
                               << 0x18U) | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                            [(0x3fU 
                                              & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                 >> 2U))] 
                                            << 0x10U)));
                    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6 
                        = ((0xffff0000U & vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6) 
                           | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))] 
                               << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                              [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                         >> 2U))]));
                }
            }
        }
        if ((4U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
            if ((1U & (~ ((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                          >> 1U)))) {
                if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d)))) {
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                    }
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                    }
                }
                if ((1U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13 
                            = ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))] 
                                << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))]);
                    }
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12 
                            = ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))] 
                                << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))]);
                    }
                }
            }
        }
    }
    vlSelf->top__DOT__dut__DOT__w_reg_write_d = ((1U 
                                                  & (~ (IData)(vlSelf->top__DOT__w_rstn))) 
                                                 && (1U 
                                                     & ((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal) 
                                                        >> 2U)));
    vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1 
        = ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_exe) 
             & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe))) 
            & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
               == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
            ? 1U : ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_mem) 
                      & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem))) 
                     & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem) 
                        == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
                     ? 2U : 0U));
    vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2 
        = ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_exe) 
             & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe))) 
            & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem) 
               == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
            ? 1U : ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_mem) 
                      & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem))) 
                     & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem) 
                        == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
                     ? 2U : 0U));
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output 
        = ((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2))
            ? vlSelf->top__DOT__dut__DOT__w_read_data2_d
            : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2))
                ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2))
                    ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                    : 0U)));
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out 
        = ((8U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
            ? ((4U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                ? ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                    ? ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                        ? vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output
                        : 0xdeadU) : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                                       ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                            ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                            : ((1U 
                                                == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                                : (
                                                   (2U 
                                                    == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                    ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                                    : 0U))) 
                                          >> (0x1fU 
                                              & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                                       : 0xdeadU)) : 
               ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                 ? 0xdeadU : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                               ? 0xdeadU : ((IData)(1U) 
                                            + (((0U 
                                                 == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                 ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                                 : 
                                                ((1U 
                                                  == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                  ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                                  : 
                                                 ((2U 
                                                   == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                   ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                                   : 0U))) 
                                               + (~ vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))))))
            : ((4U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                ? ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                    ? ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                        ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)
                        : (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) | vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                    : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                        ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) >> (0x1fU 
                                                 & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                        : (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) ^ vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)))
                : ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                    ? 0xdeadU : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                                  ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                       ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                       : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                           ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                           : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                               ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                               : 0U))) 
                                     << (0x1fU & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                                  : (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                       ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                       : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                           ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                           : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                               ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                               : 0U))) 
                                     + vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)))));
    vlSelf->top__DOT__w_rstn = vlSelf->i_rstn;
    if ((0x40U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
        if ((0x20U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
            if ((0x10U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                        = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                        >> 0x1fU))) 
                            << 0x15U) | ((0x100000U 
                                          & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 0xbU)) 
                                         | ((0xff000U 
                                             & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                            | ((0x800U 
                                                & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 9U)) 
                                               | (0x7feU 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 0x14U))))));
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                        = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                ? (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__0)
                                : 0U) : 0U);
                } else {
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
                }
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                          >> 0x14U));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__1)
                            : 0U) : 0U);
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0x800U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     << 4U)) | ((0x7e0U 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U)) 
                                                | (0x1eU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 7U)))));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 2U : 0U) : 0U);
            }
        } else {
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
        }
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f)))
                                       : ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f)))
                                       : ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__3)))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 3U))) 
                                      && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__5)))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__4))))
                                       : ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__6)))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__2)))))));
    } else if ((0x20U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
        if ((0x10U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (0xfffff000U & vlSelf->top__DOT__dut__DOT__w_instruction_f);
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 3U : 0U) : 0U);
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__imm_gen_inst0__DOT____Vxrand_h8d93fe75__0;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
        } else {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0xfe0U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     >> 0x14U)) | (0x1fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 7U))));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 1U : 0U) : 0U);
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
        }
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 4U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 3U))) 
                                  && ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 1U)) 
                                          && (1U & vlSelf->top__DOT__dut__DOT__w_instruction_f))
                                       : ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 1U)) 
                                          && (1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch 
            = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                         >> 4U))) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 3U))) 
                                      && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__1))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
            = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                         >> 4U))) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 3U))) 
                                      && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__0))))));
    } else {
        if ((0x10U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__2)
                            : 0U) : 0U);
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                          >> 0x14U));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 2U : 0U) : 0U);
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__7)))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__8)))));
        } else {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                          >> 0x14U));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 1U : 0U) : 0U);
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
        }
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 4U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 3U))) 
                                  && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 2U)) 
                                      && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 1U)) 
                                          && (1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)))));
    }
    vlSelf->top__DOT__dut__DOT__w_flush = (1U & (~ 
                                                 ((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
                                                    & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                        == 
                                                        (0x1fU 
                                                         & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 0xfU))) 
                                                       | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                          == 
                                                          (0x1fU 
                                                           & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                              >> 0x14U))))) 
                                                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                                                      & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                                                          & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                              == 
                                                              (0x1fU 
                                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 0xfU))) 
                                                             | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                                == 
                                                                (0x1fU 
                                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                    >> 0x14U))))) 
                                                         | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                            & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                                == 
                                                                (0x1fU 
                                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                    >> 0xfU))) 
                                                               | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                                  == 
                                                                  (0x1fU 
                                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                      >> 0x14U)))))))) 
                                                  | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 5U) 
                                                     & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                         == 
                                                         (0x1fU 
                                                          & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                             >> 0xfU))) 
                                                        | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                           & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                              == 
                                                              (0x1fU 
                                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 0xfU)))))))));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
        = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register
        [(0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                   >> 0xfU))];
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
        = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register
        [(0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                   >> 0x14U))];
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal 
        = (((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
              & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                  == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                               >> 0xfU))) | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                             == (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U))))) 
             | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                    & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                        == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     >> 0xfU))) | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                   == 
                                                   (0x1fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 0x14U))))) 
                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                      & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                          == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0xfU))) | 
                         ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                          == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0x14U)))))))) 
            | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                >> 5U) & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                           == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                        >> 0xfU))) 
                          | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                             & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 0xfU)))))))
            ? 0U : (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch) 
                     << 7U) | ((((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                           >> 6U))) 
                                 && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                               >> 5U))) 
                                     && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 4U))) 
                                         && ((1U & 
                                              (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 3U))) 
                                             && ((1U 
                                                  & (~ 
                                                     (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 2U))) 
                                                 && ((1U 
                                                      & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                         >> 1U)) 
                                                     && (1U 
                                                         & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                << 6U) | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg) 
                                           << 5U) | 
                                          ((((1U & 
                                              (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 6U))) 
                                             && ((1U 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 5U)) 
                                                 && ((1U 
                                                      & (~ 
                                                         (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                          >> 4U))) 
                                                     && ((1U 
                                                          & (~ 
                                                             (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                              >> 3U))) 
                                                         && ((1U 
                                                              & (~ 
                                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 2U))) 
                                                             && ((1U 
                                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                     >> 1U)) 
                                                                 && (1U 
                                                                     & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                            << 4U) 
                                           | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src) 
                                               << 3U) 
                                              | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp))))))));
    if (vlSelf->top__DOT__dut__DOT__w_flush) {
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction = 0U;
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current = 0U;
    } else {
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction 
            = vlSelf->top__DOT__dut__DOT__w_instruction_f;
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current 
            = vlSelf->top__DOT__dut__DOT__w_addr_current_f;
    }
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal 
        = (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
           == vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult 
        = (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
           < vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2);
}

void Vtop___024root___eval_nba(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_nba\n"); );
    // Body
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtop___024root___nba_sequent__TOP__0(vlSelf);
        vlSelf->__Vm_traceActivity[1U] = 1U;
    }
    if ((3ULL & vlSelf->__VnbaTriggered.word(0U))) {
        Vtop___024root___act_sequent__TOP__0(vlSelf);
    }
}

void Vtop___024root___eval_triggers__act(Vtop___024root* vlSelf);

bool Vtop___024root___eval_phase__act(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__act\n"); );
    // Init
    VlTriggerVec<2> __VpreTriggered;
    CData/*0:0*/ __VactExecute;
    // Body
    Vtop___024root___eval_triggers__act(vlSelf);
    __VactExecute = vlSelf->__VactTriggered.any();
    if (__VactExecute) {
        __VpreTriggered.andNot(vlSelf->__VactTriggered, vlSelf->__VnbaTriggered);
        vlSelf->__VnbaTriggered.thisOr(vlSelf->__VactTriggered);
        Vtop___024root___eval_act(vlSelf);
    }
    return (__VactExecute);
}

bool Vtop___024root___eval_phase__nba(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__nba\n"); );
    // Init
    CData/*0:0*/ __VnbaExecute;
    // Body
    __VnbaExecute = vlSelf->__VnbaTriggered.any();
    if (__VnbaExecute) {
        Vtop___024root___eval_nba(vlSelf);
        vlSelf->__VnbaTriggered.clear();
    }
    return (__VnbaExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__nba(Vtop___024root* vlSelf);
#endif  // VL_DEBUG
#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__act(Vtop___024root* vlSelf);
#endif  // VL_DEBUG

void Vtop___024root___eval(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval\n"); );
    // Init
    IData/*31:0*/ __VnbaIterCount;
    CData/*0:0*/ __VnbaContinue;
    // Body
    __VnbaIterCount = 0U;
    __VnbaContinue = 1U;
    while (__VnbaContinue) {
        if (VL_UNLIKELY((0x64U < __VnbaIterCount))) {
#ifdef VL_DEBUG
            Vtop___024root___dump_triggers__nba(vlSelf);
#endif
            VL_FATAL_MT("/home/khoatna/workspace/chipyard/generators/riscv32i/src/main/resources/vsrc/riscv32i/riscv32i_core/testbench/top.sv", 2, "", "NBA region did not converge.");
        }
        __VnbaIterCount = ((IData)(1U) + __VnbaIterCount);
        __VnbaContinue = 0U;
        vlSelf->__VactIterCount = 0U;
        vlSelf->__VactContinue = 1U;
        while (vlSelf->__VactContinue) {
            if (VL_UNLIKELY((0x64U < vlSelf->__VactIterCount))) {
#ifdef VL_DEBUG
                Vtop___024root___dump_triggers__act(vlSelf);
#endif
                VL_FATAL_MT("/home/khoatna/workspace/chipyard/generators/riscv32i/src/main/resources/vsrc/riscv32i/riscv32i_core/testbench/top.sv", 2, "", "Active region did not converge.");
            }
            vlSelf->__VactIterCount = ((IData)(1U) 
                                       + vlSelf->__VactIterCount);
            vlSelf->__VactContinue = 0U;
            if (Vtop___024root___eval_phase__act(vlSelf)) {
                vlSelf->__VactContinue = 1U;
            }
        }
        if (Vtop___024root___eval_phase__nba(vlSelf)) {
            __VnbaContinue = 1U;
        }
    }
}

#ifdef VL_DEBUG
void Vtop___024root___eval_debug_assertions(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_debug_assertions\n"); );
    // Body
    if (VL_UNLIKELY((vlSelf->i_clk & 0xfeU))) {
        Verilated::overWidthError("i_clk");}
    if (VL_UNLIKELY((vlSelf->i_rstn & 0xfeU))) {
        Verilated::overWidthError("i_rstn");}
}
#endif  // VL_DEBUG
