// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design internal header
// See Vtop.h for the primary calling header

#ifndef VERILATED_VTOP___024ROOT_H_
#define VERILATED_VTOP___024ROOT_H_  // guard

#include "verilated.h"


class Vtop__Syms;

class alignas(VL_CACHE_LINE_BYTES) Vtop___024root final : public VerilatedModule {
  public:

    // DESIGN SPECIFIC STATE
    // Anonymous structures to workaround compiler member-count bugs
    struct {
        VL_IN8(i_clk,0,0);
        VL_IN8(i_rstn,0,0);
        CData/*0:0*/ top__DOT__w_rstn;
        CData/*0:0*/ top__DOT__dut__DOT__w_branch_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_read_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_to_reg_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_write_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_ALU_src_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_reg_write_d;
        CData/*1:0*/ top__DOT__dut__DOT__w_ALUOp_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_funct7_30_d;
        CData/*2:0*/ top__DOT__dut__DOT__w_funct3_d;
        CData/*4:0*/ top__DOT__dut__DOT__w_rd_d;
        CData/*4:0*/ top__DOT__dut__DOT__w_rs1_d;
        CData/*4:0*/ top__DOT__dut__DOT__w_rs2_d;
        CData/*0:0*/ top__DOT__dut__DOT__w_branch_exe;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_read_exe;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_to_reg_exe;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_write_exe;
        CData/*0:0*/ top__DOT__dut__DOT__w_reg_write_exe;
        CData/*0:0*/ top__DOT__dut__DOT__w_branch_taken_exe;
        CData/*4:0*/ top__DOT__dut__DOT__w_rd_exe;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_to_reg_mem;
        CData/*0:0*/ top__DOT__dut__DOT__w_is_branch_mem;
        CData/*4:0*/ top__DOT__dut__DOT__w_rd_mem;
        CData/*0:0*/ top__DOT__dut__DOT__w_reg_write_mem;
        CData/*0:0*/ top__DOT__dut__DOT__w_branch;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_read;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_to_reg;
        CData/*0:0*/ top__DOT__dut__DOT__w_mem_write;
        CData/*0:0*/ top__DOT__dut__DOT__w_ALU_src;
        CData/*0:0*/ top__DOT__dut__DOT__w_reg_write;
        CData/*1:0*/ top__DOT__dut__DOT__w_ALUOp;
        CData/*0:0*/ top__DOT__dut__DOT__w_flush;
        CData/*1:0*/ top__DOT__dut__DOT__w_forwarding_mux_ALU1;
        CData/*1:0*/ top__DOT__dut__DOT__w_forwarding_mux_ALU2;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write;
        CData/*1:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp;
        CData/*7:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__8;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__7;
        CData/*1:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__2;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__6;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__5;
        CData/*1:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__1;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__4;
        CData/*1:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__0;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__3;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__2;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__1;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__0;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_slt;
        CData/*0:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult;
        CData/*0:0*/ top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_branch_taken;
        CData/*3:0*/ top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl;
        CData/*0:0*/ __VstlDidInit;
        CData/*0:0*/ __VstlFirstIteration;
        CData/*0:0*/ __Vtrigprevexpr___TOP__i_clk__0;
        CData/*0:0*/ __VactDidInit;
        CData/*0:0*/ __VactContinue;
    };
    struct {
        IData/*31:0*/ top__DOT__count_cyc;
        IData/*31:0*/ top__DOT__dut__DOT__w_instruction_f;
        IData/*31:0*/ top__DOT__dut__DOT__w_addr_current_f;
        IData/*31:0*/ top__DOT__dut__DOT__w_read_data1_d;
        IData/*31:0*/ top__DOT__dut__DOT__w_read_data2_d;
        IData/*31:0*/ top__DOT__dut__DOT__w_addr_current_d;
        IData/*31:0*/ top__DOT__dut__DOT__w_imm_gen_out_d;
        IData/*31:0*/ top__DOT__dut__DOT__w_addr_branch_exe;
        IData/*31:0*/ top__DOT__dut__DOT__w_ALU_out_exe;
        IData/*31:0*/ top__DOT__dut__DOT__w_read_data2_exe;
        IData/*31:0*/ top__DOT__dut__DOT__w_addr_branch_mem;
        IData/*31:0*/ top__DOT__dut__DOT__w_DMEM_out_mem;
        IData/*31:0*/ top__DOT__dut__DOT__w_ALU_out_mem;
        IData/*31:0*/ top__DOT__dut__DOT__w_write_back_wb;
        IData/*31:0*/ top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next;
        IData/*31:0*/ top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction;
        IData/*31:0*/ top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current;
        IData/*31:0*/ top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_branch;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_next;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_plus4;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out;
        IData/*31:0*/ top__DOT__dut__DOT__ID_stage_inst0__DOT__imm_gen_inst0__DOT____Vxrand_h8d93fe75__0;
        IData/*31:0*/ top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out;
        IData/*31:0*/ top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13;
        IData/*31:0*/ top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15;
        IData/*31:0*/ __Vtrigprevexpr___TOP__top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current__0;
        IData/*31:0*/ __Vtrigprevexpr___TOP__top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current__1;
        IData/*31:0*/ __VactIterCount;
        VlUnpacked<CData/*7:0*/, 1024> top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem;
        VlUnpacked<IData/*31:0*/, 32> top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register;
        VlUnpacked<CData/*7:0*/, 64> top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0;
        VlUnpacked<CData/*7:0*/, 64> top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1;
        VlUnpacked<CData/*7:0*/, 64> top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2;
        VlUnpacked<CData/*7:0*/, 64> top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3;
        VlUnpacked<CData/*0:0*/, 2> __Vm_traceActivity;
    };
    VlTriggerVec<2> __VstlTriggered;
    VlTriggerVec<2> __VactTriggered;
    VlTriggerVec<2> __VnbaTriggered;

    // INTERNAL VARIABLES
    Vtop__Syms* const vlSymsp;

    // CONSTRUCTORS
    Vtop___024root(Vtop__Syms* symsp, const char* v__name);
    ~Vtop___024root();
    VL_UNCOPYABLE(Vtop___024root);

    // INTERNAL METHODS
    void __Vconfigure(bool first);
};


#endif  // guard
