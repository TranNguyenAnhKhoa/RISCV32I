// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Design implementation internals
// See Vtop.h for the primary calling header

#include "Vtop__pch.h"
#include "Vtop___024root.h"

VL_ATTR_COLD void Vtop___024root___eval_static__TOP(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_static(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_static\n"); );
    // Body
    Vtop___024root___eval_static__TOP(vlSelf);
    vlSelf->__Vm_traceActivity[1U] = 1U;
    vlSelf->__Vm_traceActivity[0U] = 1U;
}

VL_ATTR_COLD void Vtop___024root___eval_static__TOP(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_static__TOP\n"); );
    // Body
    vlSelf->top__DOT__count_cyc = 0U;
}

VL_ATTR_COLD void Vtop___024root___eval_initial__TOP(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_initial(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_initial\n"); );
    // Body
    Vtop___024root___eval_initial__TOP(vlSelf);
    vlSelf->__Vtrigprevexpr___TOP__top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current__0 
        = vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current;
    vlSelf->__Vtrigprevexpr___TOP__top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current__1 
        = vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current;
    vlSelf->__Vtrigprevexpr___TOP__i_clk__0 = vlSelf->i_clk;
}

VL_ATTR_COLD void Vtop___024root___eval_initial__TOP(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_initial__TOP\n"); );
    // Init
    VlWide<5>/*159:0*/ __Vtemp_1;
    // Body
    __Vtemp_1[0U] = 0x2e6d656dU;
    __Vtemp_1[1U] = 0x494d454dU;
    __Vtemp_1[2U] = 0x6d656d2fU;
    __Vtemp_1[3U] = 0x6174615fU;
    __Vtemp_1[4U] = 0x2e2e2f64U;
    VL_READMEM_N(true, 8, 1024, 0, VL_CVT_PACK_STR_NW(5, __Vtemp_1)
                 ,  &(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem)
                 , 0, ~0ULL);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__8 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__7 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__2 
        = (3U & VL_RAND_RESET_I(2));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__6 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__5 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__1 
        = (3U & VL_RAND_RESET_I(2));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__4 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__0 
        = (3U & VL_RAND_RESET_I(2));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__3 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__2 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__1 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__0 
        = (1U & VL_RAND_RESET_I(1));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__imm_gen_inst0__DOT____Vxrand_h8d93fe75__0 
        = VL_RAND_RESET_I(32);
}

VL_ATTR_COLD void Vtop___024root___eval_final(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_final\n"); );
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__stl(Vtop___024root* vlSelf);
#endif  // VL_DEBUG
VL_ATTR_COLD bool Vtop___024root___eval_phase__stl(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_settle(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_settle\n"); );
    // Init
    IData/*31:0*/ __VstlIterCount;
    CData/*0:0*/ __VstlContinue;
    // Body
    __VstlIterCount = 0U;
    vlSelf->__VstlFirstIteration = 1U;
    __VstlContinue = 1U;
    while (__VstlContinue) {
        if (VL_UNLIKELY((0x64U < __VstlIterCount))) {
#ifdef VL_DEBUG
            Vtop___024root___dump_triggers__stl(vlSelf);
#endif
            VL_FATAL_MT("/home/khoatna/workspace/chipyard/generators/riscv32i/src/main/resources/vsrc/riscv32i/riscv32i_core/testbench/top.sv", 2, "", "Settle region did not converge.");
        }
        __VstlIterCount = ((IData)(1U) + __VstlIterCount);
        __VstlContinue = 0U;
        if (Vtop___024root___eval_phase__stl(vlSelf)) {
            __VstlContinue = 1U;
        }
        vlSelf->__VstlFirstIteration = 0U;
    }
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__stl(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__stl\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VstlTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 0 is active: Internal 'stl' trigger - first iteration\n");
    }
    if ((2ULL & vlSelf->__VstlTriggered.word(0U))) {
        VL_DBG_MSGF("         'stl' region trigger index 1 is active: @([hybrid] top.dut.IF_stage_inst0.w_addr_current)\n");
    }
}
#endif  // VL_DEBUG

extern const VlUnpacked<CData/*3:0*/, 64> Vtop__ConstPool__TABLE_hf09f0c7c_0;

VL_ATTR_COLD void Vtop___024root___stl_sequent__TOP__0(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___stl_sequent__TOP__0\n"); );
    // Init
    CData/*5:0*/ __Vtableidx1;
    __Vtableidx1 = 0;
    // Body
    if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe)))) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15 = 0U;
    }
    if ((0x40U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
        if ((0x20U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
            if ((0x10U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                        = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                        >> 0x1fU))) 
                            << 0x15U) | ((0x100000U 
                                          & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 0xbU)) 
                                         | ((0xff000U 
                                             & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                            | ((0x800U 
                                                & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 9U)) 
                                               | (0x7feU 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 0x14U))))));
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                        = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                ? (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__0)
                                : 0U) : 0U);
                } else {
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
                }
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                          >> 0x14U));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__1)
                            : 0U) : 0U);
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0x800U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     << 4U)) | ((0x7e0U 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U)) 
                                                | (0x1eU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 7U)))));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 2U : 0U) : 0U);
            }
        } else {
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
        }
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f)))
                                       : ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f)))
                                       : ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__3)))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 3U))) 
                                      && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__5)))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 5U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 4U))) 
                                  && ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__4))))
                                       : ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__6)))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__2)))))));
    } else if ((0x20U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
        if ((0x10U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (0xfffff000U & vlSelf->top__DOT__dut__DOT__w_instruction_f);
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 3U : 0U) : 0U);
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__imm_gen_inst0__DOT____Vxrand_h8d93fe75__0;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
        } else {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | ((0xfe0U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     >> 0x14U)) | (0x1fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 7U))));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 1U : 0U) : 0U);
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
        }
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 4U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 3U))) 
                                  && ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 1U)) 
                                          && (1U & vlSelf->top__DOT__dut__DOT__w_instruction_f))
                                       : ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 1U)) 
                                          && (1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch 
            = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                         >> 4U))) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 3U))) 
                                      && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__1))))));
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
            = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                         >> 4U))) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 3U))) 
                                      && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__0))))));
    } else {
        if ((0x10U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__2)
                            : 0U) : 0U);
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                          >> 0x14U));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 2U : 0U) : 0U);
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__7)))
                                           : ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 2U)) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && ((1U 
                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f) 
                                                  && (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__8)))));
        } else {
            if ((8U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else if ((4U & vlSelf->top__DOT__dut__DOT__w_instruction_f)) {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = 0U;
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = 0U;
            } else {
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out 
                    = (((- (IData)((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0x1fU))) << 0xcU) 
                       | (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                          >> 0x14U));
                vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp 
                    = ((2U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                        ? ((1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                            ? 1U : 0U) : 0U);
            }
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
            vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg 
                = ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                             >> 3U))) && ((1U & (~ 
                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 2U))) 
                                          && ((1U & 
                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 1U)) 
                                              && (1U 
                                                  & vlSelf->top__DOT__dut__DOT__w_instruction_f))));
        }
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch 
            = ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                      >> 4U)) && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 3U))) 
                                  && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 2U)) 
                                      && ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 1U)) 
                                          && (1U & vlSelf->top__DOT__dut__DOT__w_instruction_f)))));
    }
    if (vlSelf->top__DOT__dut__DOT__w_mem_read_exe) {
        if ((1U & (~ ((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                      >> 2U)))) {
            if ((1U & (~ ((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                          >> 1U)))) {
                if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d)))) {
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                    }
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0 
                                = (((- (IData)((1U 
                                                & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                                   [
                                                   (0x3fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                       >> 2U))] 
                                                   >> 7U)))) 
                                    << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                   [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                              >> 2U))]);
                        }
                    }
                }
                if ((1U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4 
                            = (((- (IData)((1U & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                                  [
                                                  (0x3fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                      >> 2U))] 
                                                  >> 7U)))) 
                                << 0x10U) | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                              [(0x3fU 
                                                & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                   >> 2U))] 
                                              << 8U) 
                                             | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                             [(0x3fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                  >> 2U))]));
                    }
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5 
                            = (((- (IData)((1U & (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                                  [
                                                  (0x3fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                      >> 2U))] 
                                                  >> 7U)))) 
                                << 0x10U) | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                              [(0x3fU 
                                                & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                   >> 2U))] 
                                              << 8U) 
                                             | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                             [(0x3fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                  >> 2U))]));
                    }
                }
            }
            if ((2U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
                if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d)))) {
                    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7 
                        = ((0xffffU & vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7) 
                           | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))] 
                               << 0x18U) | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                            [(0x3fU 
                                              & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                                 >> 2U))] 
                                            << 0x10U)));
                    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6 
                        = ((0xffff0000U & vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6) 
                           | ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))] 
                               << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                              [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                         >> 2U))]));
                }
            }
        }
        if ((4U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
            if ((1U & (~ ((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                          >> 1U)))) {
                if ((1U & (~ (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d)))) {
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                    }
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        if ((1U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                        if ((1U & (~ vlSelf->top__DOT__dut__DOT__w_ALU_out_exe))) {
                            vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10 
                                = vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))];
                        }
                    }
                }
                if ((1U & (IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d))) {
                    if ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                  >> 1U)))) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13 
                            = ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))] 
                                << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))]);
                    }
                    if ((2U & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)) {
                        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12 
                            = ((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                           >> 2U))] 
                                << 8U) | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                               [(0x3fU & (vlSelf->top__DOT__dut__DOT__w_ALU_out_exe 
                                          >> 2U))]);
                    }
                }
            }
        }
    }
    vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1 
        = ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_exe) 
             & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe))) 
            & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
               == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
            ? 1U : ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_mem) 
                      & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem))) 
                     & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem) 
                        == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
                     ? 2U : 0U));
    __Vtableidx1 = (((IData)(vlSelf->top__DOT__dut__DOT__w_funct7_30_d) 
                     << 5U) | (((IData)(vlSelf->top__DOT__dut__DOT__w_funct3_d) 
                                << 2U) | (IData)(vlSelf->top__DOT__dut__DOT__w_ALUOp_d)));
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl 
        = Vtop__ConstPool__TABLE_hf09f0c7c_0[__Vtableidx1];
    vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2 
        = ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_exe) 
             & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe))) 
            & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem) 
               == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
            ? 1U : ((((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_mem) 
                      & (0U != (IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem))) 
                     & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_mem) 
                        == (IData)(vlSelf->top__DOT__dut__DOT__w_rs1_d)))
                     ? 2U : 0U));
    vlSelf->top__DOT__dut__DOT__w_flush = (1U & (~ 
                                                 ((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
                                                    & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                        == 
                                                        (0x1fU 
                                                         & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 0xfU))) 
                                                       | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                          == 
                                                          (0x1fU 
                                                           & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                              >> 0x14U))))) 
                                                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                                                      & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                                                          & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                              == 
                                                              (0x1fU 
                                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 0xfU))) 
                                                             | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                                == 
                                                                (0x1fU 
                                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                    >> 0x14U))))) 
                                                         | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                            & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                                == 
                                                                (0x1fU 
                                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                    >> 0xfU))) 
                                                               | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                                  == 
                                                                  (0x1fU 
                                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                      >> 0x14U)))))))) 
                                                  | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 5U) 
                                                     & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                         == 
                                                         (0x1fU 
                                                          & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                             >> 0xfU))) 
                                                        | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                           & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                              == 
                                                              (0x1fU 
                                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 0xfU)))))))));
    vlSelf->top__DOT__dut__DOT__w_write_back_wb = ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_mem)
                                                    ? vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem
                                                    : vlSelf->top__DOT__dut__DOT__w_ALU_out_mem);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
        = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register
        [(0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                   >> 0xfU))];
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
        = vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register
        [(0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                   >> 0x14U))];
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal 
        = (((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
              & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                  == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                               >> 0xfU))) | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                             == (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U))))) 
             | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                    & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                        == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                     >> 0xfU))) | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                   == 
                                                   (0x1fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 0x14U))))) 
                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                      & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                          == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0xfU))) | 
                         ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                          == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0x14U)))))))) 
            | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                >> 5U) & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                           == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                        >> 0xfU))) 
                          | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                             & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 0xfU)))))))
            ? 0U : (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch) 
                     << 7U) | ((((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                           >> 6U))) 
                                 && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                               >> 5U))) 
                                     && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 4U))) 
                                         && ((1U & 
                                              (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 3U))) 
                                             && ((1U 
                                                  & (~ 
                                                     (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 2U))) 
                                                 && ((1U 
                                                      & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                         >> 1U)) 
                                                     && (1U 
                                                         & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                << 6U) | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg) 
                                           << 5U) | 
                                          ((((1U & 
                                              (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 6U))) 
                                             && ((1U 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 5U)) 
                                                 && ((1U 
                                                      & (~ 
                                                         (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                          >> 4U))) 
                                                     && ((1U 
                                                          & (~ 
                                                             (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                              >> 3U))) 
                                                         && ((1U 
                                                              & (~ 
                                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 2U))) 
                                                             && ((1U 
                                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                     >> 1U)) 
                                                                 && (1U 
                                                                     & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                            << 4U) 
                                           | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src) 
                                               << 3U) 
                                              | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp))))))));
    if (vlSelf->top__DOT__dut__DOT__w_flush) {
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction = 0U;
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current = 0U;
    } else {
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction 
            = vlSelf->top__DOT__dut__DOT__w_instruction_f;
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current 
            = vlSelf->top__DOT__dut__DOT__w_addr_current_f;
    }
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output 
        = ((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2))
            ? vlSelf->top__DOT__dut__DOT__w_read_data2_d
            : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2))
                ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2))
                    ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                    : 0U)));
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal 
        = (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
           == vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult 
        = (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
           < vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2);
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out 
        = ((8U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
            ? ((4U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                ? ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                    ? ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                        ? vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output
                        : 0xdeadU) : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                                       ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                            ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                            : ((1U 
                                                == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                                : (
                                                   (2U 
                                                    == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                    ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                                    : 0U))) 
                                          >> (0x1fU 
                                              & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                                       : 0xdeadU)) : 
               ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                 ? 0xdeadU : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                               ? 0xdeadU : ((IData)(1U) 
                                            + (((0U 
                                                 == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                 ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                                 : 
                                                ((1U 
                                                  == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                  ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                                  : 
                                                 ((2U 
                                                   == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                                   ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                                   : 0U))) 
                                               + (~ vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))))))
            : ((4U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                ? ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                    ? ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                        ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)
                        : (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) | vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                    : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                        ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) >> (0x1fU 
                                                 & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                        : (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                             ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                             : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                 ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                 : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                     ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                     : 0U))) ^ vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)))
                : ((2U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                    ? 0xdeadU : ((1U & (IData)(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl))
                                  ? (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                       ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                       : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                           ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                           : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                               ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                               : 0U))) 
                                     << (0x1fU & vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output))
                                  : (((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                       ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                       : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                           ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                           : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                               ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                               : 0U))) 
                                     + vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)))));
}

void Vtop___024root___act_sequent__TOP__0(Vtop___024root* vlSelf);

VL_ATTR_COLD void Vtop___024root___eval_stl(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_stl\n"); );
    // Body
    if ((1ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vtop___024root___stl_sequent__TOP__0(vlSelf);
        vlSelf->__Vm_traceActivity[1U] = 1U;
        vlSelf->__Vm_traceActivity[0U] = 1U;
    }
    if ((3ULL & vlSelf->__VstlTriggered.word(0U))) {
        Vtop___024root___act_sequent__TOP__0(vlSelf);
    }
}

VL_ATTR_COLD void Vtop___024root___eval_triggers__stl(Vtop___024root* vlSelf);

VL_ATTR_COLD bool Vtop___024root___eval_phase__stl(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___eval_phase__stl\n"); );
    // Init
    CData/*0:0*/ __VstlExecute;
    // Body
    Vtop___024root___eval_triggers__stl(vlSelf);
    __VstlExecute = vlSelf->__VstlTriggered.any();
    if (__VstlExecute) {
        Vtop___024root___eval_stl(vlSelf);
    }
    return (__VstlExecute);
}

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__act(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__act\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VactTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 0 is active: @([hybrid] top.dut.IF_stage_inst0.w_addr_current)\n");
    }
    if ((2ULL & vlSelf->__VactTriggered.word(0U))) {
        VL_DBG_MSGF("         'act' region trigger index 1 is active: @(posedge i_clk)\n");
    }
}
#endif  // VL_DEBUG

#ifdef VL_DEBUG
VL_ATTR_COLD void Vtop___024root___dump_triggers__nba(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___dump_triggers__nba\n"); );
    // Body
    if ((1U & (~ (IData)(vlSelf->__VnbaTriggered.any())))) {
        VL_DBG_MSGF("         No triggers active\n");
    }
    if ((1ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 0 is active: @([hybrid] top.dut.IF_stage_inst0.w_addr_current)\n");
    }
    if ((2ULL & vlSelf->__VnbaTriggered.word(0U))) {
        VL_DBG_MSGF("         'nba' region trigger index 1 is active: @(posedge i_clk)\n");
    }
}
#endif  // VL_DEBUG

VL_ATTR_COLD void Vtop___024root___ctor_var_reset(Vtop___024root* vlSelf) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root___ctor_var_reset\n"); );
    // Body
    vlSelf->i_clk = VL_RAND_RESET_I(1);
    vlSelf->i_rstn = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__w_rstn = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__count_cyc = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_instruction_f = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_addr_current_f = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_branch_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_read_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_write_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_ALU_src_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_reg_write_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_ALUOp_d = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__w_read_data1_d = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_read_data2_d = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_funct7_30_d = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_funct3_d = VL_RAND_RESET_I(3);
    vlSelf->top__DOT__dut__DOT__w_rd_d = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__dut__DOT__w_rs1_d = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__dut__DOT__w_rs2_d = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__dut__DOT__w_addr_current_d = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_branch_exe = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_read_exe = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg_exe = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_write_exe = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_reg_write_exe = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_addr_branch_exe = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_branch_taken_exe = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_ALU_out_exe = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_read_data2_exe = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_rd_exe = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg_mem = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_is_branch_mem = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_addr_branch_mem = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_ALU_out_mem = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_write_back_wb = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__w_rd_mem = VL_RAND_RESET_I(5);
    vlSelf->top__DOT__dut__DOT__w_reg_write_mem = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_branch = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_read = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_mem_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_ALU_src = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_ALUOp = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__w_flush = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1 = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2 = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 1024; ++__Vi0) {
        vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__IMEM_inst0__DOT__imem[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_branch = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_next = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_plus4 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal = VL_RAND_RESET_I(8);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__8 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__7 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__2 = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__6 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__5 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__1 = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__4 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d9647ad__0 = VL_RAND_RESET_I(2);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__3 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__2 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__1 = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__controller_inst0__DOT____Vxrand_h8d96565c__0 = VL_RAND_RESET_I(1);
    for (int __Vi0 = 0; __Vi0 < 32; ++__Vi0) {
        vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[__Vi0] = VL_RAND_RESET_I(32);
    }
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_slt = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__imm_gen_inst0__DOT____Vxrand_h8d93fe75__0 = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_branch_taken = VL_RAND_RESET_I(1);
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl = VL_RAND_RESET_I(4);
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out = VL_RAND_RESET_I(32);
    vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output = VL_RAND_RESET_I(32);
    for (int __Vi0 = 0; __Vi0 < 64; ++__Vi0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0[__Vi0] = VL_RAND_RESET_I(8);
    }
    for (int __Vi0 = 0; __Vi0 < 64; ++__Vi0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1[__Vi0] = VL_RAND_RESET_I(8);
    }
    for (int __Vi0 = 0; __Vi0 < 64; ++__Vi0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2[__Vi0] = VL_RAND_RESET_I(8);
    }
    for (int __Vi0 = 0; __Vi0 < 64; ++__Vi0) {
        vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3[__Vi0] = VL_RAND_RESET_I(8);
    }
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13 = 0;
    vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15 = 0;
    vlSelf->__Vtrigprevexpr___TOP__top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current__0 = VL_RAND_RESET_I(32);
    vlSelf->__VstlDidInit = 0;
    vlSelf->__Vtrigprevexpr___TOP__top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current__1 = VL_RAND_RESET_I(32);
    vlSelf->__Vtrigprevexpr___TOP__i_clk__0 = VL_RAND_RESET_I(1);
    vlSelf->__VactDidInit = 0;
    for (int __Vi0 = 0; __Vi0 < 2; ++__Vi0) {
        vlSelf->__Vm_traceActivity[__Vi0] = 0;
    }
}
