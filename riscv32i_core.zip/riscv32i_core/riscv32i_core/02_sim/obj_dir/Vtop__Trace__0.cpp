// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_fst_c.h"
#include "Vtop__Syms.h"


void Vtop___024root__trace_chg_0_sub_0(Vtop___024root* vlSelf, VerilatedFst::Buffer* bufp);

void Vtop___024root__trace_chg_0(void* voidSelf, VerilatedFst::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_chg_0\n"); );
    // Init
    Vtop___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtop___024root*>(voidSelf);
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    if (VL_UNLIKELY(!vlSymsp->__Vm_activity)) return;
    // Body
    Vtop___024root__trace_chg_0_sub_0((&vlSymsp->TOP), bufp);
}

void Vtop___024root__trace_chg_0_sub_0(Vtop___024root* vlSelf, VerilatedFst::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_chg_0_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode + 1);
    // Body
    if (VL_UNLIKELY(vlSelf->__Vm_traceActivity[1U])) {
        bufp->chgBit(oldp+0,(vlSelf->top__DOT__w_rstn));
        bufp->chgIData(oldp+1,(vlSelf->top__DOT__count_cyc),32);
        bufp->chgIData(oldp+2,(vlSelf->top__DOT__dut__DOT__w_instruction_f),32);
        bufp->chgIData(oldp+3,(vlSelf->top__DOT__dut__DOT__w_addr_current_f),32);
        bufp->chgBit(oldp+4,(vlSelf->top__DOT__dut__DOT__w_branch_d));
        bufp->chgBit(oldp+5,(vlSelf->top__DOT__dut__DOT__w_mem_read_d));
        bufp->chgBit(oldp+6,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_d));
        bufp->chgBit(oldp+7,(vlSelf->top__DOT__dut__DOT__w_mem_write_d));
        bufp->chgBit(oldp+8,(vlSelf->top__DOT__dut__DOT__w_ALU_src_d));
        bufp->chgBit(oldp+9,(vlSelf->top__DOT__dut__DOT__w_reg_write_d));
        bufp->chgCData(oldp+10,(vlSelf->top__DOT__dut__DOT__w_ALUOp_d),2);
        bufp->chgIData(oldp+11,(vlSelf->top__DOT__dut__DOT__w_read_data1_d),32);
        bufp->chgIData(oldp+12,(vlSelf->top__DOT__dut__DOT__w_read_data2_d),32);
        bufp->chgBit(oldp+13,(vlSelf->top__DOT__dut__DOT__w_funct7_30_d));
        bufp->chgCData(oldp+14,(vlSelf->top__DOT__dut__DOT__w_funct3_d),3);
        bufp->chgCData(oldp+15,(vlSelf->top__DOT__dut__DOT__w_rd_d),5);
        bufp->chgCData(oldp+16,(vlSelf->top__DOT__dut__DOT__w_rs1_d),5);
        bufp->chgCData(oldp+17,(vlSelf->top__DOT__dut__DOT__w_rs2_d),5);
        bufp->chgIData(oldp+18,(vlSelf->top__DOT__dut__DOT__w_addr_current_d),32);
        bufp->chgIData(oldp+19,(vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d),32);
        bufp->chgBit(oldp+20,((1U & ((0x4000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                      ? ((0x2000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                          ? ((0x1000U 
                                              & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                              ? (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))
                                              : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))
                                          : ((0x1000U 
                                              & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                              ? (((vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                                   >> 0x1fU) 
                                                  != 
                                                  (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                                   >> 0x1fU))
                                                  ? 
                                                 (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                                  >> 0x1fU)
                                                  : 
                                                 (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult)))
                                              : (((vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                                   >> 0x1fU) 
                                                  != 
                                                  (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                                   >> 0x1fU))
                                                  ? 
                                                 (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                                  >> 0x1fU)
                                                  : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))))
                                      : ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 0xdU))) 
                                         && (1U & (
                                                   (0x1000U 
                                                    & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                                    ? 
                                                   (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal))
                                                    : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal))))))));
        bufp->chgBit(oldp+21,(vlSelf->top__DOT__dut__DOT__w_branch_exe));
        bufp->chgBit(oldp+22,(vlSelf->top__DOT__dut__DOT__w_mem_read_exe));
        bufp->chgBit(oldp+23,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_exe));
        bufp->chgBit(oldp+24,(vlSelf->top__DOT__dut__DOT__w_mem_write_exe));
        bufp->chgBit(oldp+25,(vlSelf->top__DOT__dut__DOT__w_reg_write_exe));
        bufp->chgIData(oldp+26,(vlSelf->top__DOT__dut__DOT__w_addr_branch_exe),32);
        bufp->chgIData(oldp+27,(vlSelf->top__DOT__dut__DOT__w_ALU_out_exe),32);
        bufp->chgIData(oldp+28,(vlSelf->top__DOT__dut__DOT__w_read_data2_exe),32);
        bufp->chgCData(oldp+29,(vlSelf->top__DOT__dut__DOT__w_rd_exe),5);
        bufp->chgBit(oldp+30,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_mem));
        bufp->chgIData(oldp+31,(vlSelf->top__DOT__dut__DOT__w_addr_branch_mem),32);
        bufp->chgIData(oldp+32,(vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem),32);
        bufp->chgIData(oldp+33,(vlSelf->top__DOT__dut__DOT__w_ALU_out_mem),32);
        bufp->chgIData(oldp+34,(vlSelf->top__DOT__dut__DOT__w_write_back_wb),32);
        bufp->chgCData(oldp+35,(vlSelf->top__DOT__dut__DOT__w_rd_mem),5);
        bufp->chgBit(oldp+36,(vlSelf->top__DOT__dut__DOT__w_reg_write_mem));
        bufp->chgBit(oldp+37,(vlSelf->top__DOT__dut__DOT__w_flush));
        bufp->chgBit(oldp+38,((1U & (~ ((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
                                          & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                              == (0x1fU 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 0xfU))) 
                                             | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                == 
                                                (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U))))) 
                                         | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                                            & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                                                & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 0xfU))) 
                                                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                      == 
                                                      (0x1fU 
                                                       & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                          >> 0x14U))))) 
                                               | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                  & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                      == 
                                                      (0x1fU 
                                                       & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                          >> 0xfU))) 
                                                     | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                        == 
                                                        (0x1fU 
                                                         & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 0x14U)))))))) 
                                        | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 5U) 
                                           & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                               == (0x1fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 0xfU))) 
                                              | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                 & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 0xfU)))))))))));
        bufp->chgBit(oldp+39,(((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
                                 & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                     == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 0xfU))) 
                                    | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                       == (0x1fU & 
                                           (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                            >> 0x14U))))) 
                                | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                                   & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                                       & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                           == (0x1fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 0xfU))) 
                                          | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                             == (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U))))) 
                                      | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                         & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                             == (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0xfU))) 
                                            | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                               == (0x1fU 
                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                      >> 0x14U)))))))) 
                               | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                   >> 5U) & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                              == (0x1fU 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 0xfU))) 
                                             | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                   == 
                                                   (0x1fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 0xfU)))))))));
        bufp->chgCData(oldp+40,(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1),2);
        bufp->chgCData(oldp+41,(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2),2);
        bufp->chgIData(oldp+42,(((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                  ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                                  : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                      ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                      : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                          ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                          : 0U)))),32);
        bufp->chgIData(oldp+43,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output),32);
        bufp->chgCData(oldp+44,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl),4);
        bufp->chgIData(oldp+45,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out),32);
        bufp->chgIData(oldp+46,((vlSelf->top__DOT__dut__DOT__w_addr_current_d 
                                 + vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d)),32);
        bufp->chgIData(oldp+47,((~ vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)),32);
        bufp->chgIData(oldp+48,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1),32);
        bufp->chgIData(oldp+49,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2),32);
        bufp->chgIData(oldp+50,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out),32);
        bufp->chgBit(oldp+51,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch));
        bufp->chgBit(oldp+52,(((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                         >> 6U))) && 
                               ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                          >> 5U))) 
                                && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                              >> 4U))) 
                                    && ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 3U))) 
                                        && ((1U & (~ 
                                                   (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 2U))) 
                                            && ((1U 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 1U)) 
                                                && (1U 
                                                    & vlSelf->top__DOT__dut__DOT__w_instruction_f)))))))));
        bufp->chgBit(oldp+53,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg));
        bufp->chgBit(oldp+54,(((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                         >> 6U))) && 
                               ((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 5U)) && (
                                                   (1U 
                                                    & (~ 
                                                       (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 4U))) 
                                                   && ((1U 
                                                        & (~ 
                                                           (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 3U))) 
                                                       && ((1U 
                                                            & (~ 
                                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                >> 2U))) 
                                                           && ((1U 
                                                                & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                   >> 1U)) 
                                                               && (1U 
                                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f)))))))));
        bufp->chgBit(oldp+55,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src));
        bufp->chgBit(oldp+56,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write));
        bufp->chgCData(oldp+57,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp),2);
        bufp->chgCData(oldp+58,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal),8);
        bufp->chgCData(oldp+59,((0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                          >> 0xfU))),5);
        bufp->chgCData(oldp+60,((0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                          >> 0x14U))),5);
        bufp->chgIData(oldp+61,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0]),32);
        bufp->chgIData(oldp+62,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[1]),32);
        bufp->chgIData(oldp+63,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[2]),32);
        bufp->chgIData(oldp+64,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[3]),32);
        bufp->chgIData(oldp+65,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[4]),32);
        bufp->chgIData(oldp+66,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[5]),32);
        bufp->chgIData(oldp+67,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[6]),32);
        bufp->chgIData(oldp+68,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[7]),32);
        bufp->chgIData(oldp+69,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[8]),32);
        bufp->chgIData(oldp+70,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[9]),32);
        bufp->chgIData(oldp+71,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[10]),32);
        bufp->chgIData(oldp+72,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[11]),32);
        bufp->chgIData(oldp+73,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[12]),32);
        bufp->chgIData(oldp+74,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[13]),32);
        bufp->chgIData(oldp+75,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[14]),32);
        bufp->chgIData(oldp+76,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[15]),32);
        bufp->chgIData(oldp+77,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[16]),32);
        bufp->chgIData(oldp+78,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[17]),32);
        bufp->chgIData(oldp+79,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[18]),32);
        bufp->chgIData(oldp+80,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[19]),32);
        bufp->chgIData(oldp+81,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[20]),32);
        bufp->chgIData(oldp+82,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[21]),32);
        bufp->chgIData(oldp+83,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[22]),32);
        bufp->chgIData(oldp+84,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[23]),32);
        bufp->chgIData(oldp+85,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[24]),32);
        bufp->chgIData(oldp+86,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[25]),32);
        bufp->chgIData(oldp+87,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[26]),32);
        bufp->chgIData(oldp+88,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[27]),32);
        bufp->chgIData(oldp+89,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[28]),32);
        bufp->chgIData(oldp+90,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[29]),32);
        bufp->chgIData(oldp+91,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[30]),32);
        bufp->chgIData(oldp+92,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[31]),32);
        bufp->chgCData(oldp+93,((7U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0xcU))),3);
        bufp->chgBit(oldp+94,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal));
        bufp->chgBit(oldp+95,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult));
        bufp->chgCData(oldp+96,((0x7fU & vlSelf->top__DOT__dut__DOT__w_instruction_f)),7);
        bufp->chgCData(oldp+97,((((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch) 
                                  << 7U) | ((((1U & 
                                               (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 6U))) 
                                              && ((1U 
                                                   & (~ 
                                                      (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 5U))) 
                                                  && ((1U 
                                                       & (~ 
                                                          (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                           >> 4U))) 
                                                      && ((1U 
                                                           & (~ 
                                                              (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                               >> 3U))) 
                                                          && ((1U 
                                                               & (~ 
                                                                  (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                   >> 2U))) 
                                                              && ((1U 
                                                                   & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                      >> 1U)) 
                                                                  && (1U 
                                                                      & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                             << 6U) 
                                            | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg) 
                                                << 5U) 
                                               | ((((1U 
                                                     & (~ 
                                                        (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                         >> 6U))) 
                                                    && ((1U 
                                                         & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 5U)) 
                                                        && ((1U 
                                                             & (~ 
                                                                (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                 >> 4U))) 
                                                            && ((1U 
                                                                 & (~ 
                                                                    (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                     >> 3U))) 
                                                                && ((1U 
                                                                     & (~ 
                                                                        (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                         >> 2U))) 
                                                                    && ((1U 
                                                                         & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                            >> 1U)) 
                                                                        && (1U 
                                                                            & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                                   << 4U) 
                                                  | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src) 
                                                      << 3U) 
                                                     | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write) 
                                                         << 2U) 
                                                        | (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp)))))))),8);
        bufp->chgIData(oldp+98,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current),32);
        bufp->chgIData(oldp+99,((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0 
                                 | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1 
                                    | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2 
                                       | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3 
                                          | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4 
                                             | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5 
                                                | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6 
                                                   | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7 
                                                      | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8 
                                                         | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9 
                                                            | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10 
                                                               | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11 
                                                                  | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12 
                                                                     | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13 
                                                                        | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15))))))))))))))),32);
        bufp->chgCData(oldp+100,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                                 [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
        bufp->chgCData(oldp+101,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                                 [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
        bufp->chgCData(oldp+102,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                                 [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
        bufp->chgCData(oldp+103,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                                 [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
        bufp->chgIData(oldp+104,(VL_SHIFTR_III(32,32,32, vlSelf->top__DOT__dut__DOT__w_ALU_out_exe, 2U)),32);
        bufp->chgBit(oldp+105,((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                      >> 5U))));
    }
    bufp->chgBit(oldp+106,(vlSelf->i_clk));
    bufp->chgBit(oldp+107,(vlSelf->i_rstn));
    bufp->chgIData(oldp+108,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next),32);
    bufp->chgIData(oldp+109,(((IData)(4U) + vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current)),32);
    bufp->chgIData(oldp+110,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction),32);
    bufp->chgIData(oldp+111,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current),32);
}

void Vtop___024root__trace_cleanup(void* voidSelf, VerilatedFst* /*unused*/) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_cleanup\n"); );
    // Init
    Vtop___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtop___024root*>(voidSelf);
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    vlSymsp->__Vm_activity = false;
    vlSymsp->TOP.__Vm_traceActivity[0U] = 0U;
    vlSymsp->TOP.__Vm_traceActivity[1U] = 0U;
}
