// Verilated -*- C++ -*-
// DESCRIPTION: Verilator output: Tracing implementation internals
#include "verilated_fst_c.h"
#include "Vtop__Syms.h"


VL_ATTR_COLD void Vtop___024root__trace_init_sub__TOP__0(Vtop___024root* vlSelf, VerilatedFst* tracep) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_init_sub__TOP__0\n"); );
    // Init
    const int c = vlSymsp->__Vm_baseCode;
    // Body
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+108,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->pushPrefix("top", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+108,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"w_rstn",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+2,0,"count_cyc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->pushPrefix("dut", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+3,0,"w_instruction_f",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+4,0,"w_addr_current_f",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+5,0,"w_branch_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+6,0,"w_mem_read_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+7,0,"w_mem_to_reg_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"w_mem_write_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+9,0,"w_ALU_src_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+10,0,"w_reg_write_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+11,0,"w_ALUOp_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+12,0,"w_read_data1_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+13,0,"w_read_data2_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+14,0,"w_funct7_30_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+15,0,"w_funct3_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+16,0,"w_rd_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+17,0,"w_rs1_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+18,0,"w_rs2_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+19,0,"w_addr_current_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"w_imm_gen_out_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+21,0,"w_branch_taken_d",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+22,0,"w_branch_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+23,0,"w_mem_read_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+24,0,"w_mem_to_reg_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+25,0,"w_mem_write_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+26,0,"w_reg_write_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+27,0,"w_addr_branch_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+113,0,"w_branch_taken_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+28,0,"w_ALU_out_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+29,0,"w_read_data2_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+30,0,"w_rd_exe",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+31,0,"w_mem_to_reg_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+114,0,"w_is_branch_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+32,0,"w_addr_branch_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+33,0,"w_DMEM_out_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+34,0,"w_ALU_out_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+35,0,"w_write_back_wb",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+36,0,"w_rd_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+37,0,"w_reg_write_mem",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+115,0,"w_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+116,0,"w_mem_read",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+117,0,"w_mem_to_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+118,0,"w_mem_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+119,0,"w_ALU_src",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+120,0,"w_reg_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+121,0,"w_ALUOp",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBit(c+38,0,"w_flush",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+39,0,"w_write_PC",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+40,0,"w_control_mux",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+41,0,"w_forwarding_mux_ALU1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+42,0,"w_forwarding_mux_ALU2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->pushPrefix("EXE_stage_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+5,0,"i_branch",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+6,0,"i_mem_read",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+7,0,"i_mem_to_reg",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"i_mem_write",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+9,0,"i_ALU_src",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+10,0,"i_reg_write",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+11,0,"i_ALUOp",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+19,0,"i_addr_current",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+12,0,"i_read_data1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+13,0,"i_read_data2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"i_imm_gen_out",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+14,0,"i_funct7_30",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+15,0,"i_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+16,0,"i_rd",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+28,0,"i_ALU_result_MEM",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+35,0,"i_data_wire_back",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+41,0,"i_sel_mux1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+42,0,"i_sel_mux2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBit(c+22,0,"o_branch",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+23,0,"o_mem_read",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+24,0,"o_mem_to_reg",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+25,0,"o_mem_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+26,0,"o_reg_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+27,0,"o_addr_branch",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+28,0,"o_ALU_out",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+29,0,"o_mux_alu2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+30,0,"o_rd",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+5,0,"w_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+6,0,"w_mem_read",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+7,0,"w_mem_to_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"w_mem_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+10,0,"w_reg_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+122,0,"w_branch_taken",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+43,0,"w_mux_alu1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+44,0,"w_mux_alu2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+45,0,"w_ALUCtrl",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBus(c+46,0,"w_ALU_out",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+47,0,"w_addr_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+16,0,"w_rd",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->pushPrefix("ALU_control_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+11,0,"i_ALUOp",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+15,0,"i_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+14,0,"i_funct7_30",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+45,0,"o_ALUCtrl",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->popPrefix();
    tracep->pushPrefix("ALU_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+43,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+44,0,"i_input2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+45,0,"i_ALUCtrl",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 3,0);
    tracep->declBus(c+46,0,"o_resutl",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+48,0,"w_input2n",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("adder_addr_inst1", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+19,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"i_input2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+47,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("mux_alu1_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+123,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+12,0,"i_input0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+35,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+28,0,"i_input2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+41,0,"i_sel",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+43,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+43,0,"r_output",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("mux_alu2_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+123,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+13,0,"i_input0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+35,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+28,0,"i_input2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+42,0,"i_sel",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+44,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+44,0,"r_output",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("ID_stage_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+3,0,"i_instruction",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+4,0,"i_addr_current",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+35,0,"i_write_back",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+36,0,"i_rd",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+37,0,"i_reg_write",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+40,0,"i_control_mux",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+5,0,"o_branch",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+6,0,"o_mem_read",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+7,0,"o_mem_to_reg",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+8,0,"o_mem_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+9,0,"o_ALU_src",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+10,0,"o_reg_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+11,0,"o_ALUOp",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+12,0,"o_read_data1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+13,0,"o_read_data2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+14,0,"o_funct7_30",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+15,0,"o_funct3",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+17,0,"o_rs1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+18,0,"o_rs2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+16,0,"o_rd",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+19,0,"o_addr_current",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+20,0,"o_imm_gen_out",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+21,0,"o_branch_taken",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+3,0,"w_instruction",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+4,0,"w_addr_current",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+124,0,"w_addr_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+125,0,"w_addr_next",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+126,0,"w_addr_plus4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+49,0,"w_read_data1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+50,0,"w_read_data2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+51,0,"w_imm_gen_out",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+52,0,"w_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+53,0,"w_mem_read",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+54,0,"w_mem_to_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+55,0,"w_mem_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"w_ALU_src",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+57,0,"w_reg_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+58,0,"w_ALUOp",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+59,0,"w_control_signal",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->pushPrefix("RF_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+60,0,"i_read_reg1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+61,0,"i_read_reg2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+36,0,"i_write_reg",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+35,0,"i_write_data",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+37,0,"i_reg_write_en",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+49,0,"o_read_data1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+50,0,"o_read_data2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->pushPrefix("register", VerilatedTracePrefixType::ARRAY_UNPACKED);
    for (int i = 0; i < 32; ++i) {
        tracep->declBus(c+62+i*1,0,"",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, true,(i+0), 31,0);
    }
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("comparator_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+49,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+50,0,"i_input2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+94,0,"i_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+21,0,"o_branch_taken",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+95,0,"w_equal",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+127,0,"w_slt",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+96,0,"w_ult",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+128,0,"equal",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+129,0,"not_equal",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+130,0,"less_than",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+131,0,"greater_than_or_eq",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+132,0,"less_than_u",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+133,0,"greater_than_or_eq_u",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->popPrefix();
    tracep->pushPrefix("controller_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+3,0,"i_instructions",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+52,0,"o_branch",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+53,0,"o_mem_read",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+54,0,"o_mem_to_reg",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+55,0,"o_mem_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+56,0,"o_ALU_src",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+57,0,"o_reg_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+58,0,"o_ALUOp",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+134,0,"Load",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+135,0,"jalr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+136,0,"Imm_A_L",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+137,0,"R_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+138,0,"Store",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+139,0,"B_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+140,0,"Lui",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+141,0,"auipc",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+142,0,"jal",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->declBus(c+97,0,"opcode",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 6,0);
    tracep->popPrefix();
    tracep->pushPrefix("imm_gen_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+3,0,"i_instructions",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+51,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+143,0,"R_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+144,0,"I_type1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+145,0,"I_type2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+146,0,"I_type3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+147,0,"S_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+148,0,"B_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+149,0,"U_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+150,0,"J_type",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->popPrefix();
    tracep->pushPrefix("mux_hazard_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+151,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+98,0,"i_input0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+152,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBit(c+40,0,"i_sel",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+59,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("IF_stage_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+21,0,"i_is_branch",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+38,0,"i_flush",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+39,0,"i_write_PC",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+32,0,"i_addr_branch",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+3,0,"o_instruction",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+4,0,"o_addr_current",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+109,0,"w_addr_next",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+110,0,"w_addr_plus4",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+111,0,"w_instruction",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+112,0,"w_addr_current",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->pushPrefix("IMEM_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+112,0,"i_address",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+111,0,"o_instructions",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("PC_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+39,0,"i_write_en",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+109,0,"i_PC_next",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+112,0,"o_PC_current",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+99,0,"r_PC_current",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::VAR, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("adder4_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+112,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+153,0,"i_input2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+110,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->pushPrefix("mux_branch_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+123,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+110,0,"i_input0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+32,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+21,0,"i_sel",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+109,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("MEM_stage_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+1,0,"i_rstn",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+23,0,"i_mem_read",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+25,0,"i_mem_write",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+26,0,"i_reg_write",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+24,0,"i_mem_to_reg",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+28,0,"i_ALU_out",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+27,0,"i_addr_branch",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+29,0,"i_read_data2",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+30,0,"i_rd",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+15,0,"i_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBit(c+31,0,"o_mem_to_reg",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+37,0,"o_reg_write",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+33,0,"o_DMEM_out",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+34,0,"o_ALU_out",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+32,0,"o_addr_branch",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+36,0,"o_rd",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+26,0,"w_reg_write",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+24,0,"w_mem_to_reg",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+100,0,"w_DMEM_out",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+28,0,"w_ALU_out",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+29,0,"w_read_data2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+27,0,"w_addr_branch",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+30,0,"w_rd",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->pushPrefix("DMEM_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+107,0,"i_clk",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+28,0,"i_address",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+29,0,"i_data",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+25,0,"i_mem_write",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+23,0,"i_mem_read",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+15,0,"i_funct3",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+100,0,"o_data",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+128,0,"sb_lb",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+129,0,"sh_lh",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+154,0,"sw_lw",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+130,0,"lbu",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+131,0,"lhu",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 2,0);
    tracep->declBus(c+101,0,"w_bank3",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+102,0,"w_bank2",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+103,0,"w_bank1",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+104,0,"w_bank0",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 7,0);
    tracep->declBus(c+105,0,"w_idx_addr",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->pushPrefix("forwarding_unit_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBit(c+26,0,"i_reg_write_EXMEM",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+37,0,"i_reg_write_MEMWB",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+17,0,"i_rs1_IDEX",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+17,0,"i_rs2_IDEX",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+30,0,"i_rd_EXMEM",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+36,0,"i_rd_MEMWB",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+41,0,"o_mux_ALU1",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->declBus(c+42,0,"o_mux_ALU2",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 1,0);
    tracep->popPrefix();
    tracep->pushPrefix("hazard_detection_unit_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+60,0,"i_rs1_IFID",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+61,0,"i_rs2_IFID",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+16,0,"i_rd_IDEX",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBus(c+30,0,"i_rd_EXMEM",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 4,0);
    tracep->declBit(c+10,0,"i_write_reg_IDEX",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+6,0,"i_mem_read_IDEX",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+23,0,"i_mem_read_EXMEM",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+5,0,"i_branch_ID",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+106,0,"i_is_jalr",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+38,0,"o_write_IDEX",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+39,0,"o_write_PC",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBit(c+40,0,"o_control_mux",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->popPrefix();
    tracep->pushPrefix("mux_wb_inst0", VerilatedTracePrefixType::SCOPE_MODULE);
    tracep->declBus(c+123,0,"WIDTH",-1, VerilatedTraceSigDirection::NONE, VerilatedTraceSigKind::PARAMETER, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+34,0,"i_input0",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBus(c+33,0,"i_input1",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->declBit(c+31,0,"i_sel",-1, VerilatedTraceSigDirection::INPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1);
    tracep->declBus(c+35,0,"o_output",-1, VerilatedTraceSigDirection::OUTPUT, VerilatedTraceSigKind::WIRE, VerilatedTraceSigType::LOGIC, false,-1, 31,0);
    tracep->popPrefix();
    tracep->popPrefix();
    tracep->popPrefix();
}

VL_ATTR_COLD void Vtop___024root__trace_init_top(Vtop___024root* vlSelf, VerilatedFst* tracep) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_init_top\n"); );
    // Body
    Vtop___024root__trace_init_sub__TOP__0(vlSelf, tracep);
}

VL_ATTR_COLD void Vtop___024root__trace_const_0(void* voidSelf, VerilatedFst::Buffer* bufp);
VL_ATTR_COLD void Vtop___024root__trace_full_0(void* voidSelf, VerilatedFst::Buffer* bufp);
void Vtop___024root__trace_chg_0(void* voidSelf, VerilatedFst::Buffer* bufp);
void Vtop___024root__trace_cleanup(void* voidSelf, VerilatedFst* /*unused*/);

VL_ATTR_COLD void Vtop___024root__trace_register(Vtop___024root* vlSelf, VerilatedFst* tracep) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_register\n"); );
    // Body
    tracep->addConstCb(&Vtop___024root__trace_const_0, 0U, vlSelf);
    tracep->addFullCb(&Vtop___024root__trace_full_0, 0U, vlSelf);
    tracep->addChgCb(&Vtop___024root__trace_chg_0, 0U, vlSelf);
    tracep->addCleanupCb(&Vtop___024root__trace_cleanup, vlSelf);
}

VL_ATTR_COLD void Vtop___024root__trace_const_0_sub_0(Vtop___024root* vlSelf, VerilatedFst::Buffer* bufp);

VL_ATTR_COLD void Vtop___024root__trace_const_0(void* voidSelf, VerilatedFst::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_const_0\n"); );
    // Init
    Vtop___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtop___024root*>(voidSelf);
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    Vtop___024root__trace_const_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void Vtop___024root__trace_const_0_sub_0(Vtop___024root* vlSelf, VerilatedFst::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_const_0_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullBit(oldp+113,(vlSelf->top__DOT__dut__DOT__w_branch_taken_exe));
    bufp->fullBit(oldp+114,(vlSelf->top__DOT__dut__DOT__w_is_branch_mem));
    bufp->fullBit(oldp+115,(vlSelf->top__DOT__dut__DOT__w_branch));
    bufp->fullBit(oldp+116,(vlSelf->top__DOT__dut__DOT__w_mem_read));
    bufp->fullBit(oldp+117,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg));
    bufp->fullBit(oldp+118,(vlSelf->top__DOT__dut__DOT__w_mem_write));
    bufp->fullBit(oldp+119,(vlSelf->top__DOT__dut__DOT__w_ALU_src));
    bufp->fullBit(oldp+120,(vlSelf->top__DOT__dut__DOT__w_reg_write));
    bufp->fullCData(oldp+121,(vlSelf->top__DOT__dut__DOT__w_ALUOp),2);
    bufp->fullBit(oldp+122,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_branch_taken));
    bufp->fullIData(oldp+123,(0x20U),32);
    bufp->fullIData(oldp+124,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_branch),32);
    bufp->fullIData(oldp+125,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_next),32);
    bufp->fullIData(oldp+126,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_addr_plus4),32);
    bufp->fullBit(oldp+127,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_slt));
    bufp->fullCData(oldp+128,(0U),3);
    bufp->fullCData(oldp+129,(1U),3);
    bufp->fullCData(oldp+130,(4U),3);
    bufp->fullCData(oldp+131,(5U),3);
    bufp->fullCData(oldp+132,(6U),3);
    bufp->fullCData(oldp+133,(7U),3);
    bufp->fullCData(oldp+134,(3U),7);
    bufp->fullCData(oldp+135,(0x67U),7);
    bufp->fullCData(oldp+136,(0x13U),7);
    bufp->fullCData(oldp+137,(0x33U),7);
    bufp->fullCData(oldp+138,(0x23U),7);
    bufp->fullCData(oldp+139,(0x63U),7);
    bufp->fullCData(oldp+140,(0x37U),7);
    bufp->fullCData(oldp+141,(0x17U),7);
    bufp->fullCData(oldp+142,(0x6fU),7);
    bufp->fullCData(oldp+143,(0xcU),5);
    bufp->fullCData(oldp+144,(0U),5);
    bufp->fullCData(oldp+145,(4U),5);
    bufp->fullCData(oldp+146,(0x19U),5);
    bufp->fullCData(oldp+147,(8U),5);
    bufp->fullCData(oldp+148,(0x18U),5);
    bufp->fullCData(oldp+149,(0xdU),5);
    bufp->fullCData(oldp+150,(0x1bU),5);
    bufp->fullIData(oldp+151,(8U),32);
    bufp->fullCData(oldp+152,(0U),8);
    bufp->fullIData(oldp+153,(4U),32);
    bufp->fullCData(oldp+154,(2U),3);
}

VL_ATTR_COLD void Vtop___024root__trace_full_0_sub_0(Vtop___024root* vlSelf, VerilatedFst::Buffer* bufp);

VL_ATTR_COLD void Vtop___024root__trace_full_0(void* voidSelf, VerilatedFst::Buffer* bufp) {
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_full_0\n"); );
    // Init
    Vtop___024root* const __restrict vlSelf VL_ATTR_UNUSED = static_cast<Vtop___024root*>(voidSelf);
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    // Body
    Vtop___024root__trace_full_0_sub_0((&vlSymsp->TOP), bufp);
}

VL_ATTR_COLD void Vtop___024root__trace_full_0_sub_0(Vtop___024root* vlSelf, VerilatedFst::Buffer* bufp) {
    (void)vlSelf;  // Prevent unused variable warning
    Vtop__Syms* const __restrict vlSymsp VL_ATTR_UNUSED = vlSelf->vlSymsp;
    VL_DEBUG_IF(VL_DBG_MSGF("+    Vtop___024root__trace_full_0_sub_0\n"); );
    // Init
    uint32_t* const oldp VL_ATTR_UNUSED = bufp->oldp(vlSymsp->__Vm_baseCode);
    // Body
    bufp->fullBit(oldp+1,(vlSelf->top__DOT__w_rstn));
    bufp->fullIData(oldp+2,(vlSelf->top__DOT__count_cyc),32);
    bufp->fullIData(oldp+3,(vlSelf->top__DOT__dut__DOT__w_instruction_f),32);
    bufp->fullIData(oldp+4,(vlSelf->top__DOT__dut__DOT__w_addr_current_f),32);
    bufp->fullBit(oldp+5,(vlSelf->top__DOT__dut__DOT__w_branch_d));
    bufp->fullBit(oldp+6,(vlSelf->top__DOT__dut__DOT__w_mem_read_d));
    bufp->fullBit(oldp+7,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_d));
    bufp->fullBit(oldp+8,(vlSelf->top__DOT__dut__DOT__w_mem_write_d));
    bufp->fullBit(oldp+9,(vlSelf->top__DOT__dut__DOT__w_ALU_src_d));
    bufp->fullBit(oldp+10,(vlSelf->top__DOT__dut__DOT__w_reg_write_d));
    bufp->fullCData(oldp+11,(vlSelf->top__DOT__dut__DOT__w_ALUOp_d),2);
    bufp->fullIData(oldp+12,(vlSelf->top__DOT__dut__DOT__w_read_data1_d),32);
    bufp->fullIData(oldp+13,(vlSelf->top__DOT__dut__DOT__w_read_data2_d),32);
    bufp->fullBit(oldp+14,(vlSelf->top__DOT__dut__DOT__w_funct7_30_d));
    bufp->fullCData(oldp+15,(vlSelf->top__DOT__dut__DOT__w_funct3_d),3);
    bufp->fullCData(oldp+16,(vlSelf->top__DOT__dut__DOT__w_rd_d),5);
    bufp->fullCData(oldp+17,(vlSelf->top__DOT__dut__DOT__w_rs1_d),5);
    bufp->fullCData(oldp+18,(vlSelf->top__DOT__dut__DOT__w_rs2_d),5);
    bufp->fullIData(oldp+19,(vlSelf->top__DOT__dut__DOT__w_addr_current_d),32);
    bufp->fullIData(oldp+20,(vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d),32);
    bufp->fullBit(oldp+21,((1U & ((0x4000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                   ? ((0x2000U & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                       ? ((0x1000U 
                                           & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))
                                           : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))
                                       : ((0x1000U 
                                           & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                           ? (((vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                                >> 0x1fU) 
                                               != (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                                   >> 0x1fU))
                                               ? (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                                  >> 0x1fU)
                                               : (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult)))
                                           : (((vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                                >> 0x1fU) 
                                               != (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2 
                                                   >> 0x1fU))
                                               ? (vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1 
                                                  >> 0x1fU)
                                               : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult))))
                                   : ((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                >> 0xdU))) 
                                      && (1U & ((0x1000U 
                                                 & vlSelf->top__DOT__dut__DOT__w_instruction_f)
                                                 ? 
                                                (~ (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal))
                                                 : (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal))))))));
    bufp->fullBit(oldp+22,(vlSelf->top__DOT__dut__DOT__w_branch_exe));
    bufp->fullBit(oldp+23,(vlSelf->top__DOT__dut__DOT__w_mem_read_exe));
    bufp->fullBit(oldp+24,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_exe));
    bufp->fullBit(oldp+25,(vlSelf->top__DOT__dut__DOT__w_mem_write_exe));
    bufp->fullBit(oldp+26,(vlSelf->top__DOT__dut__DOT__w_reg_write_exe));
    bufp->fullIData(oldp+27,(vlSelf->top__DOT__dut__DOT__w_addr_branch_exe),32);
    bufp->fullIData(oldp+28,(vlSelf->top__DOT__dut__DOT__w_ALU_out_exe),32);
    bufp->fullIData(oldp+29,(vlSelf->top__DOT__dut__DOT__w_read_data2_exe),32);
    bufp->fullCData(oldp+30,(vlSelf->top__DOT__dut__DOT__w_rd_exe),5);
    bufp->fullBit(oldp+31,(vlSelf->top__DOT__dut__DOT__w_mem_to_reg_mem));
    bufp->fullIData(oldp+32,(vlSelf->top__DOT__dut__DOT__w_addr_branch_mem),32);
    bufp->fullIData(oldp+33,(vlSelf->top__DOT__dut__DOT__w_DMEM_out_mem),32);
    bufp->fullIData(oldp+34,(vlSelf->top__DOT__dut__DOT__w_ALU_out_mem),32);
    bufp->fullIData(oldp+35,(vlSelf->top__DOT__dut__DOT__w_write_back_wb),32);
    bufp->fullCData(oldp+36,(vlSelf->top__DOT__dut__DOT__w_rd_mem),5);
    bufp->fullBit(oldp+37,(vlSelf->top__DOT__dut__DOT__w_reg_write_mem));
    bufp->fullBit(oldp+38,(vlSelf->top__DOT__dut__DOT__w_flush));
    bufp->fullBit(oldp+39,((1U & (~ ((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
                                       & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                           == (0x1fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 0xfU))) 
                                          | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                             == (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0x14U))))) 
                                      | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                                         & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                                             & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                 == 
                                                 (0x1fU 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 0xfU))) 
                                                | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                   == 
                                                   (0x1fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 0x14U))))) 
                                            | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                               & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                   == 
                                                   (0x1fU 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 0xfU))) 
                                                  | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                     == 
                                                     (0x1fU 
                                                      & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                         >> 0x14U)))))))) 
                                     | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                         >> 5U) & (
                                                   ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                                    == 
                                                    (0x1fU 
                                                     & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 0xfU))) 
                                                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                                      & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                         == 
                                                         (0x1fU 
                                                          & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                             >> 0xfU)))))))))));
    bufp->fullBit(oldp+40,(((((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_d) 
                              & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                  == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                               >> 0xfU))) 
                                 | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                    == (0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 0x14U))))) 
                             | ((IData)(vlSelf->top__DOT__dut__DOT__w_branch_d) 
                                & (((IData)(vlSelf->top__DOT__dut__DOT__w_reg_write_d) 
                                    & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                        == (0x1fU & 
                                            (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                             >> 0xfU))) 
                                       | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                          == (0x1fU 
                                              & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 0x14U))))) 
                                   | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                      & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                          == (0x1fU 
                                              & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                 >> 0xfU))) 
                                         | ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                            == (0x1fU 
                                                & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 0x14U)))))))) 
                            | ((vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                >> 5U) & (((IData)(vlSelf->top__DOT__dut__DOT__w_rd_d) 
                                           == (0x1fU 
                                               & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 0xfU))) 
                                          | ((IData)(vlSelf->top__DOT__dut__DOT__w_mem_read_exe) 
                                             & ((IData)(vlSelf->top__DOT__dut__DOT__w_rd_exe) 
                                                == 
                                                (0x1fU 
                                                 & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 0xfU)))))))));
    bufp->fullCData(oldp+41,(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1),2);
    bufp->fullCData(oldp+42,(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU2),2);
    bufp->fullIData(oldp+43,(((0U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                               ? vlSelf->top__DOT__dut__DOT__w_read_data1_d
                               : ((1U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                   ? vlSelf->top__DOT__dut__DOT__w_write_back_wb
                                   : ((2U == (IData)(vlSelf->top__DOT__dut__DOT__w_forwarding_mux_ALU1))
                                       ? vlSelf->top__DOT__dut__DOT__w_ALU_out_exe
                                       : 0U)))),32);
    bufp->fullIData(oldp+44,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output),32);
    bufp->fullCData(oldp+45,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALUCtrl),4);
    bufp->fullIData(oldp+46,(vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__w_ALU_out),32);
    bufp->fullIData(oldp+47,((vlSelf->top__DOT__dut__DOT__w_addr_current_d 
                              + vlSelf->top__DOT__dut__DOT__w_imm_gen_out_d)),32);
    bufp->fullIData(oldp+48,((~ vlSelf->top__DOT__dut__DOT__EXE_stage_inst0__DOT__mux_alu2_inst0__DOT__r_output)),32);
    bufp->fullIData(oldp+49,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data1),32);
    bufp->fullIData(oldp+50,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_read_data2),32);
    bufp->fullIData(oldp+51,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_imm_gen_out),32);
    bufp->fullBit(oldp+52,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch));
    bufp->fullBit(oldp+53,(((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                      >> 6U))) && (
                                                   (1U 
                                                    & (~ 
                                                       (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 5U))) 
                                                   && ((1U 
                                                        & (~ 
                                                           (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 4U))) 
                                                       && ((1U 
                                                            & (~ 
                                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                >> 3U))) 
                                                           && ((1U 
                                                                & (~ 
                                                                   (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                    >> 2U))) 
                                                               && ((1U 
                                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                       >> 1U)) 
                                                                   && (1U 
                                                                       & vlSelf->top__DOT__dut__DOT__w_instruction_f)))))))));
    bufp->fullBit(oldp+54,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg));
    bufp->fullBit(oldp+55,(((1U & (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                      >> 6U))) && (
                                                   (1U 
                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                       >> 5U)) 
                                                   && ((1U 
                                                        & (~ 
                                                           (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 4U))) 
                                                       && ((1U 
                                                            & (~ 
                                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                >> 3U))) 
                                                           && ((1U 
                                                                & (~ 
                                                                   (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                    >> 2U))) 
                                                               && ((1U 
                                                                    & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                       >> 1U)) 
                                                                   && (1U 
                                                                       & vlSelf->top__DOT__dut__DOT__w_instruction_f)))))))));
    bufp->fullBit(oldp+56,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src));
    bufp->fullBit(oldp+57,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write));
    bufp->fullCData(oldp+58,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp),2);
    bufp->fullCData(oldp+59,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_control_signal),8);
    bufp->fullCData(oldp+60,((0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0xfU))),5);
    bufp->fullCData(oldp+61,((0x1fU & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                       >> 0x14U))),5);
    bufp->fullIData(oldp+62,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[0]),32);
    bufp->fullIData(oldp+63,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[1]),32);
    bufp->fullIData(oldp+64,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[2]),32);
    bufp->fullIData(oldp+65,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[3]),32);
    bufp->fullIData(oldp+66,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[4]),32);
    bufp->fullIData(oldp+67,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[5]),32);
    bufp->fullIData(oldp+68,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[6]),32);
    bufp->fullIData(oldp+69,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[7]),32);
    bufp->fullIData(oldp+70,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[8]),32);
    bufp->fullIData(oldp+71,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[9]),32);
    bufp->fullIData(oldp+72,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[10]),32);
    bufp->fullIData(oldp+73,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[11]),32);
    bufp->fullIData(oldp+74,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[12]),32);
    bufp->fullIData(oldp+75,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[13]),32);
    bufp->fullIData(oldp+76,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[14]),32);
    bufp->fullIData(oldp+77,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[15]),32);
    bufp->fullIData(oldp+78,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[16]),32);
    bufp->fullIData(oldp+79,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[17]),32);
    bufp->fullIData(oldp+80,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[18]),32);
    bufp->fullIData(oldp+81,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[19]),32);
    bufp->fullIData(oldp+82,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[20]),32);
    bufp->fullIData(oldp+83,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[21]),32);
    bufp->fullIData(oldp+84,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[22]),32);
    bufp->fullIData(oldp+85,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[23]),32);
    bufp->fullIData(oldp+86,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[24]),32);
    bufp->fullIData(oldp+87,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[25]),32);
    bufp->fullIData(oldp+88,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[26]),32);
    bufp->fullIData(oldp+89,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[27]),32);
    bufp->fullIData(oldp+90,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[28]),32);
    bufp->fullIData(oldp+91,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[29]),32);
    bufp->fullIData(oldp+92,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[30]),32);
    bufp->fullIData(oldp+93,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__RF_inst0__DOT__register[31]),32);
    bufp->fullCData(oldp+94,((7U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                    >> 0xcU))),3);
    bufp->fullBit(oldp+95,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_equal));
    bufp->fullBit(oldp+96,(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__comparator_inst0__DOT__w_ult));
    bufp->fullCData(oldp+97,((0x7fU & vlSelf->top__DOT__dut__DOT__w_instruction_f)),7);
    bufp->fullCData(oldp+98,((((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_branch) 
                               << 7U) | ((((1U & (~ 
                                                  (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                   >> 6U))) 
                                           && ((1U 
                                                & (~ 
                                                   (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                    >> 5U))) 
                                               && ((1U 
                                                    & (~ 
                                                       (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                        >> 4U))) 
                                                   && ((1U 
                                                        & (~ 
                                                           (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                            >> 3U))) 
                                                       && ((1U 
                                                            & (~ 
                                                               (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                >> 2U))) 
                                                           && ((1U 
                                                                & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                   >> 1U)) 
                                                               && (1U 
                                                                   & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                          << 6U) | 
                                         (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_mem_to_reg) 
                                           << 5U) | 
                                          ((((1U & 
                                              (~ (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                  >> 6U))) 
                                             && ((1U 
                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                     >> 5U)) 
                                                 && ((1U 
                                                      & (~ 
                                                         (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                          >> 4U))) 
                                                     && ((1U 
                                                          & (~ 
                                                             (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                              >> 3U))) 
                                                         && ((1U 
                                                              & (~ 
                                                                 (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                  >> 2U))) 
                                                             && ((1U 
                                                                  & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                                                     >> 1U)) 
                                                                 && (1U 
                                                                     & vlSelf->top__DOT__dut__DOT__w_instruction_f))))))) 
                                            << 4U) 
                                           | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALU_src) 
                                               << 3U) 
                                              | (((IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_reg_write) 
                                                  << 2U) 
                                                 | (IData)(vlSelf->top__DOT__dut__DOT__ID_stage_inst0__DOT__w_ALUOp)))))))),8);
    bufp->fullIData(oldp+99,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__PC_inst0__DOT__r_PC_current),32);
    bufp->fullIData(oldp+100,((vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out0 
                               | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out1 
                                  | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out2 
                                     | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out3 
                                        | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out4 
                                           | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out5 
                                              | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out6 
                                                 | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out7 
                                                    | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out8 
                                                       | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out9 
                                                          | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out10 
                                                             | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out11 
                                                                | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out12 
                                                                   | (vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out13 
                                                                      | vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__o_data__out__strong__out15))))))))))))))),32);
    bufp->fullCData(oldp+101,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank3
                              [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
    bufp->fullCData(oldp+102,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank2
                              [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
    bufp->fullCData(oldp+103,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank1
                              [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
    bufp->fullCData(oldp+104,(vlSelf->top__DOT__dut__DOT__MEM_stage_inst0__DOT__DMEM_inst0__DOT__bank0
                              [(0x3fU & vlSelf->top__DOT__dut__DOT__w_ALU_out_exe)]),8);
    bufp->fullIData(oldp+105,(VL_SHIFTR_III(32,32,32, vlSelf->top__DOT__dut__DOT__w_ALU_out_exe, 2U)),32);
    bufp->fullBit(oldp+106,((1U & (vlSelf->top__DOT__dut__DOT__w_instruction_f 
                                   >> 5U))));
    bufp->fullBit(oldp+107,(vlSelf->i_clk));
    bufp->fullBit(oldp+108,(vlSelf->i_rstn));
    bufp->fullIData(oldp+109,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_next),32);
    bufp->fullIData(oldp+110,(((IData)(4U) + vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current)),32);
    bufp->fullIData(oldp+111,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_instruction),32);
    bufp->fullIData(oldp+112,(vlSelf->top__DOT__dut__DOT__IF_stage_inst0__DOT__w_addr_current),32);
}
